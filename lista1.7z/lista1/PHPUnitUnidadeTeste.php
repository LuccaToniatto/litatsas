<?php

use  PHPUnit\Framework\TestCase;

require_once("PhpUnitUnidade.php");

class PHPUnitUnidadeTeste extends TestCase
{
    public function testValidadeQtdePares()
    {
        $numeros = [2, 4, 6, 8, 10];

        $phpUnitUnidade = new PHPUnitUnidade();
        $result = $phpUnitUnidade->validaQtdePares($numeros);
        $this->assertGreaterThan(3, $result);

    }

    public function testeCalculadora()
    {
        $n1 = 1;
        $n2 = 2;
        $operacao = 4;
        $phpUnitUnidade = new PHPUnitUnidade();
        $result = $phpUnitUnidade->calculadora($n1,$n2,$operacao);
        $this->assertEquals(2,$result);
    }

    public function testestring()
    {
      $string = "cinco";
      $phpUnitUnidade = new PHPUnitUnidade();
      $result = $phpUnitUnidade->checastring($string);
      $this->assertGreaterThanOrEqual(5,$result);
    }

    public function testesenha()
    {
        $senha = "Senai2022";
        $phpUnitUnidade = new PHPUnitUnidade();
        $result = $phpUnitUnidade->senha($senha);
        $this->assertSame('881cae19c0e9fc6456fae89462f5157fca0f3fa7d010841a0382f98de9144866',$result);
    }

    public function testerenda()
    {
        $valor = 4664.69;
        $phpUnitUnidade = new PHPUnitUnidade();
        $result = $phpUnitUnidade->renda($valor);
        $this->assertEquals(869.36,$result);
    }

    public function testeestados()
    {
        $valor = 2;
        $phpUnitUnidade = new PHPUnitUnidade();
        $string = $phpUnitUnidade->estados($valor);
        $this->assertSame('Alagoas',$string);
    }

    public function testerandom()
    {
        $phpUnitUnidade = new PHPUnitUnidade();
        $contador = $phpUnitUnidade->random();
        foreach($contador as $numero)
        {
            $this->assertIsInt($numero);
        }
    }
}
?>