<?php 

class PhpUnitUnidade{
    public function validaQtdePares($numeros)
    {

        $pares = 0;
        foreach($numeros as $numero)
        {
            if($numero %2 == 0 )
            {
                $pares++;
            }
            
        }
        return $pares;
    }

    public function calculadora($n1, $n2, $operacao)
    {
        if($operacao == 1)
        {
            $result = $n1 + $n2;
            return $result;
        }

        if($operacao == 2)
        {
            $result = $n1 - $n2;
            return $result;
        }

        if($operacao == 3)
        {
            $result = $n1/$n2;
            return $result;
        }

        if($operacao == 4)
        {
            $result = $n1*$n2;
            return $result;
        }
        else
        {

        }


    }
    public function checastring($string)
    {
        $result = strlen($string);
        return $result;
    }

    public function senha($senha)
    {
        $result = hash('sha256', $senha);
        return $result;
    }

    public function renda($valor)
    {
        if($valor < 1903.98)
        {
            $result = 0;
            
        }
        if($valor >= 1903.99 && $valor <= 2826.65)
        {
            $result = 142.80;
            
        }
        if($valor >= 2826.66 && $valor   <= 3751.05)
        {
            $result = 354.80;
            
        }
        if($valor >= 3751.06 && $valor   <= 4664.68)
        {
            $result = 636.13;
            
        }
        if($valor > 4664.68)
        {
            $result = 869.36;
            
        }
        return $result;
    }
    public function estados($valor)
    {
        $estados = array(
            1 => 'Acre',
            2 => 'Alagoas',
            3 => 'Amapa',
            4 => 'Amazonas',
            5 => 'Bahia',
            6 => 'Ceara',
            7 => 'Distrito Federal',
            8 => 'Espirito Santo',
            9 => 'Goias',
            10 => 'Maranhão',
            11 => 'Mato Grosso',
            12 => 'Mato Grosso do Sul',
            13 => 'Minas Gerais',
            14 => 'Pará',
            15 => 'Paraná',
            16 => 'Paraiba',
            17 => 'Pernambuco',
            18 => 'Piauí',
            19 => 'Rio de Janeiro',
            20 => 'Rio Grande do Norte',
            21 => 'Rio Grande do Sul',
            22 => 'Rondonia',
            23 => 'Santa Catarina',
            24 => 'São Paulo',
            25 => 'Sergipe',
            26 => 'Tocantins',
            );

        $string = $estados[$valor];
        return $string;
    }

    public function random()
    {
        $numero_sorteados=[];
        $i = 0;
        while($i<=60)
        {
            $i++;
            $a = rand(1,9);
            array_push($numero_sorteados, $a);
        }
        return $numero_sorteados;
    }
}

?>